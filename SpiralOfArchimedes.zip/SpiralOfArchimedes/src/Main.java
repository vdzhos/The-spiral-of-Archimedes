import org.jfree.chart.ChartPanel;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

public class Main extends JFrame {

    /**The main window of a program*/
    private JFrame frame;
    /**The panel to hold a JFreeChart component*/
    private ChartPanel chartPanel;
    /**Object of a class, which initialises the JFreeChart component and has useful methods to work with it*/
    private Chart chart;

    /**The right panel on the program window, displays information about the graph*/
    private JPanel info;
    /**changes the "a" parameter in a range from -100k to 100k*/
    private JSpinner aParSpinner;
    /**changes the "s" (Start of a diapason of φ) parameter in a range from -100k to 100k*/
    private JSpinner diapSpinnerStart;
    /**changes the "e" (End of a diapason of φ) parameter in a range from -100k to 100k*/
    private JSpinner diapSpinnerEnd;
    /**changes the step in a range from 4 to 136*/
    private JSpinner stepSpinner;

    /**The bottom panel on the program window, holds sliders to change the graph's parameters*/
    private JPanel settings;
    /**changes the "s" (Start of a diapason of φ) parameter in a range from -10 to 10*/
    private JSlider diapasonStartSlider;
    /**changes the "e" (End of a diapason of φ) parameter in a range from -10 to 10*/
    private JSlider diapasonEndSlider;
    /**changes the "a" parameter in a range from -20 to 20*/
    private JSlider aParSlider;
    /**changes the step (the change of the angle to find the points of the graph) in a range from 4 to 136*/
    private JSlider stepSlider;
    /**The flag, which regulates the use of sliders and corresponding spinners*/
    private boolean slider = true;

    /**Creates the program's window with all needed components initialised*/
    public Main(){
        frame = this;

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setLayout(new BorderLayout());
        this.setPreferredSize(new Dimension(1290,980));
        this.setResizable(false);
        this.setVisible(true);

        initChartPanel();
        initInfoPanel();
        initSettingsPanel();

        this.add(chartPanel, BorderLayout.CENTER);
        this.add(info, BorderLayout.EAST);
        this.add(settings, BorderLayout.SOUTH);
        this.pack();
    }

    /**Initialises the ChartPanel, that holds JFreeChart component (graph)*/
    private void initChartPanel() {
        chart = new Chart();
        chartPanel = new ChartPanel(chart.getChart());
        chartPanel.setZoomInFactor(0.75);
        chartPanel.setZoomOutFactor(1.25);
        chartPanel.setZoomAroundAnchor(true);
        chartPanel.setMouseZoomable(false);
        chartPanel.addMouseWheelListener(new MouseWheelListener() {
            @Override
            public void mouseWheelMoved(MouseWheelEvent e) {
                if(e.getScrollType() != MouseWheelEvent.WHEEL_UNIT_SCROLL){
                    return;
                }
                if(e.getWheelRotation()< 0){
                    zoomChartAxis(e,true);
                }else {
                    zoomChartAxis(e,false);
                }
            }
        });
    }

    /**@param e - the mouse wheel event (to get the mouse coordinates)
     * @param increase - the flag, determines whether to zoom in or out
     * Defines the behaviour of zooming (in and out)*/
    private void zoomChartAxis(MouseWheelEvent e, boolean increase){
        if(increase){
            chartPanel.zoomInBoth(e.getX(),e.getY());
        }else{
            chartPanel.zoomOutBoth(e.getX(),e.getY());
        }

    }

    /**Initialises the info panel, which holds info about the graph*/
    private void initInfoPanel() {
        info = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        info.setPreferredSize(new Dimension(250,550));
        info.setBackground(new Color(229, 255, 223));
        info.setBorder(BorderFactory.createMatteBorder(1,1,0,0,Color.BLACK));

        Font fontF = new Font("Segoe UI Semibold",Font.ITALIC, 24);
        Font fontP = new Font("Segoe UI Semibold",Font.BOLD, 28);

        JLabel name = new JLabel("<html><div style='text-align: center;'>The spiral of<br>Archimedes</html>");
        name.setFont(new Font("Eras Demi ITC",Font.BOLD, 32));
        gbc.insets = new Insets(0,0,15,0);
        gbc.gridx = 0;
        gbc.gridy = 0;
        info.add(name,gbc);


        initFormulas(gbc, fontP, fontF);
        initParameters(gbc, fontP,fontF);
        initConstraints(gbc, fontP,fontF);
    }

    /**@param gbc - GidBagConstraints object (to add components to GridBagLayout panel)
     * @param fontP - the font for "Formulas" heading
     * @param fontF - the font for formulas themselves
     * Initialises the "Formulas" part of the info panel*/
    private void initFormulas(GridBagConstraints gbc, Font fontP, Font fontF) {
        JLabel formulas = new JLabel("Formulas:");
        gbc.insets = new Insets(0,0,0,85);
        formulas.setFont(fontP);
        gbc.gridy = 1;
        info.add(formulas,gbc);

        JLabel mainF = new JLabel("r = aφ");
        gbc.insets = new Insets(0,0,0,128);
        mainF.setFont(fontF);
        gbc.gridy = 2;
        info.add(mainF,gbc);

        JLabel xF = new JLabel("x = rcos(φ)");
        gbc.insets = new Insets(0,0,0,82);
        xF.setFont(fontF);
        gbc.gridy = 3;
        info.add(xF,gbc);

        JLabel yF = new JLabel("y = rsin(φ)");
        gbc.insets = new Insets(0,0,50,83);
        yF.setFont(fontF);
        gbc.gridy = 4;
        info.add(yF,gbc);
    }

    /**@param gbc - GidBagConstraints object (to add components to GridBagLayout panel)
     * @param fontP - the font for "Parameters" heading
     * @param fontF - the font for parameters themselves
     * Initialises the "Parameters" part of the info panel*/
    private void initParameters(GridBagConstraints gbc, Font fontP, Font fontF){
        JLabel parameters = new JLabel("Parameters:");
        gbc.insets = new Insets(0,0,0,58);
        parameters.setFont(fontP);
        gbc.gridy = 5;
        info.add(parameters,gbc);

        Color color = new Color(229, 255, 223);

        JPanel aParPanel = new JPanel(new GridBagLayout());
        JPanel diapasonPanel = new JPanel(new GridBagLayout());
        JPanel diapasonPanelStart = new JPanel(new GridBagLayout());
        JPanel diapasonPanelEnd = new JPanel(new GridBagLayout());
        JPanel stepPanel = new JPanel(new GridBagLayout());

        aParPanel.setBackground(color);
        diapasonPanel.setBackground(color);
        diapasonPanelStart.setBackground(color);
        diapasonPanelEnd.setBackground(color);
        stepPanel.setBackground(color);

        Dimension dim = new Dimension(85,35);
        Font fontSp = new Font("SanSerif", Font.PLAIN,16);

        JLabel aPar = new JLabel("a = ");
        aPar.setFont(fontF);
        gbc.insets = new Insets(0,0,0,0);
        gbc.gridx = 0;
        gbc.gridy = 0;
        aParPanel.add(aPar, gbc);

        aParSpinner = new JSpinner(new SpinnerNumberModel(1, -100000, 100000, 1));
        aParSpinner.setPreferredSize(new Dimension(100,35));
        aParSpinner.setFont(fontSp);
        gbc.insets = new Insets(0,0,0,28);
        gbc.gridx = 1;
        gbc.gridy = 0;
        aParPanel.add(aParSpinner, gbc);

        aParSpinner.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                if(slider){
                    slider = false;
                    if((int)aParSpinner.getValue()>=-20 && (int)aParSpinner.getValue()<=20){
                        aParSlider.setValue((int)aParSpinner.getValue());
                        slider = true;
                    }else if((int)aParSpinner.getValue()<-20){
                        aParSlider.setValue(-20);
                        slider = true;
                    }else{
                        aParSlider.setValue(20);
                        slider = true;
                    }
                }
                chart.setAPar((int)aParSpinner.getValue());
                chart.getChart().getXYPlot().setDataset(chart.generateDataset());
            }
        });

        gbc.gridx = 0;
        gbc.gridy = 6;
        info.add(aParPanel,gbc);

        JLabel diapason = new JLabel("φ = [sπ; eπ]");
        gbc.insets = new Insets(0,0,0,69);
        diapason.setFont(fontF);
        gbc.gridx = 0;
        gbc.gridy = 0;
        diapasonPanel.add(diapason, gbc);

        JLabel diapasonStart = new JLabel("Start(s) = ");
        gbc.insets = new Insets(0,0,0,0);
        diapasonStart.setFont(fontF);
        gbc.gridx = 0;
        gbc.gridy = 0;
        diapasonPanelStart.add(diapasonStart, gbc);

        diapSpinnerStart = new JSpinner(new SpinnerNumberModel(0, -100000, 100000, 1));
        diapSpinnerStart.setPreferredSize(dim);
        diapSpinnerStart.setFont(fontSp);
        gbc.insets = new Insets(0,0,0,7);
        gbc.gridx = 1;
        gbc.gridy = 0;
        diapasonPanelStart.add(diapSpinnerStart, gbc);
        diapSpinnerStart.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                if((int)diapSpinnerStart.getValue()> (int)diapSpinnerEnd.getValue()){
                    diapSpinnerStart.setValue(diapSpinnerEnd.getValue());
                }else{
                    if(slider) {
                        slider = false;
                        if ((int) diapSpinnerStart.getValue() >= -10 && (int) diapSpinnerStart.getValue() <= 10) {
                            diapasonStartSlider.setValue((int) diapSpinnerStart.getValue());
                            slider = true;
                        } else if ((int) diapSpinnerStart.getValue() < -10) {
                            diapasonStartSlider.setValue(-10);
                            slider = true;
                        } else {
                            diapasonStartSlider.setValue(10);
                            slider = true;
                        }
                    }
                }
                chart.setDiapasonStart((int)diapSpinnerStart.getValue());
                chart.getChart().getXYPlot().setDataset(chart.generateDataset());
            }
        });

        JLabel diapasonEnd = new JLabel("End(e) = ");
        gbc.insets = new Insets(0,0,0,9);
        diapasonEnd.setFont(fontF);
        gbc.gridx = 0;
        gbc.gridy = 0;
        diapasonPanelEnd.add(diapasonEnd, gbc);

        diapSpinnerEnd = new JSpinner(new SpinnerNumberModel(4, -100000, 100000, 1));
        diapSpinnerEnd.setPreferredSize(dim);
        diapSpinnerEnd.setFont(fontSp);
        gbc.insets = new Insets(0,0,0,8);
        gbc.gridx = 1;
        gbc.gridy = 0;
        diapasonPanelEnd.add(diapSpinnerEnd, gbc);
        diapSpinnerEnd.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                if((int)diapSpinnerEnd.getValue()<(int)diapSpinnerStart.getValue()){
                    diapSpinnerEnd.setValue(diapSpinnerStart.getValue());
                }else{
                    if(slider) {
                        slider = false;
                        if ((int) diapSpinnerEnd.getValue() >= -10 && (int) diapSpinnerEnd.getValue() <= 10) {
                            diapasonEndSlider.setValue((int) diapSpinnerEnd.getValue());
                            slider = true;
                        } else if ((int) diapSpinnerEnd.getValue() < -10) {
                            diapasonEndSlider.setValue(-10);
                            slider = true;
                        } else {
                            diapasonEndSlider.setValue(10);
                            slider = true;
                        }
                    }
                }
                chart.setDiapasonEnd((int)diapSpinnerEnd.getValue());
                chart.getChart().getXYPlot().setDataset(chart.generateDataset());
            }
        });


        JLabel step = new JLabel("Step = π / ");
        gbc.insets = new Insets(0,0,0,0);
        step.setFont(fontF);
        gbc.gridx = 0;
        gbc.gridy = 0;
        stepPanel.add(step, gbc);

        stepSpinner = new JSpinner(new SpinnerNumberModel(32, 4, 136, 1));
        stepSpinner.setPreferredSize(new Dimension(50,35));
        stepSpinner.setFont(fontSp);
        gbc.insets = new Insets(0,0,0,32);
        gbc.gridx = 1;
        gbc.gridy = 0;
        stepPanel.add(stepSpinner, gbc);
        stepSpinner.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                if(slider) {
                    slider = false;
                    if ((int) stepSpinner.getValue() >= 4 && (int) stepSpinner.getValue() <= 136) {
                        stepSlider.setValue((int) stepSpinner.getValue());
                        slider = true;
                    } else if ((int) aParSpinner.getValue() < 4) {
                        stepSlider.setValue(4);
                        slider = true;
                    } else {
                        stepSlider.setValue(136);
                        slider = true;
                    }
                }
                chart.setStep((int)stepSpinner.getValue());
                chart.getChart().getXYPlot().setDataset(chart.generateDataset());
            }
        });

        gbc.insets = new Insets(0,0,0,0);
        gbc.gridx = 0;
        gbc.gridy = 7;
        info.add(diapasonPanel,gbc);

        gbc.gridx = 0;
        gbc.gridy = 8;
        info.add(diapasonPanelStart,gbc);

        gbc.gridx = 0;
        gbc.gridy = 9;
        info.add(diapasonPanelEnd,gbc);

        gbc.gridx = 0;
        gbc.gridy = 10;
        info.add(stepPanel,gbc);
    }

    /**@param gbc - GidBagConstraints object (to add components to GridBagLayout panel)
     * @param fontP - the font for "Constraints" heading
     * @param fontF - the font for constraints themselves
     * Initialises the "Constraints" part of the info panel*/
    private void initConstraints(GridBagConstraints gbc, Font fontP, Font fontF) {
        JLabel constraints = new JLabel("Constraints:");
        gbc.insets = new Insets(50,0,0,55);
        constraints.setFont(fontP);
        gbc.gridy = 11;
        info.add(constraints,gbc);

        JLabel aPar = new JLabel("a = [-100k; 100k]");
        gbc.insets = new Insets(0,0,0,10);
        aPar.setFont(fontF);
        gbc.gridy = 12;
        info.add(aPar,gbc);

        JLabel sPar = new JLabel("s = [-100k; 100k]");
        sPar.setFont(fontF);
        gbc.gridy = 13;
        info.add(sPar,gbc);

        JLabel ePar = new JLabel("e = [-100k; 100k]");
        ePar.setFont(fontF);
        gbc.gridy = 14;
        info.add(ePar,gbc);

        JLabel stepPar = new JLabel("Step = [π/136; π/4]");
        gbc.insets = new Insets(0,10,0,0);
        stepPar.setFont(fontF);
        gbc.gridy = 15;
        info.add(stepPar,gbc);
    }

    /**Initialises the settings panel, which holds the sliders to change the graph's parameters*/
    private void initSettingsPanel() {
        settings = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        settings.setPreferredSize(new Dimension(frame.getPreferredSize().width,180));
        settings.setBackground(new Color(229, 255, 223));
        settings.setBorder(BorderFactory.createMatteBorder(1,0,0,0,Color.BLACK));

        Dimension dim = new Dimension(300,60);
        Font font = new Font("Segoe UI Semibold",Font.BOLD, 16);
        Color color = new Color(229, 255, 223);

        JPanel left = new JPanel(new GridBagLayout());
        JPanel center = new JPanel(new GridBagLayout());
        JPanel right = new JPanel(new GridBagLayout());

        left.setBackground(color);
        center.setBackground(color);
        right.setBackground(color);

        JLabel diapasonLabel = new JLabel("Parameters s and e: [sπ; eπ]");
        diapasonLabel.setFont(font);
        gbc.gridx = 0;
        gbc.gridy = 0;
        left.add(diapasonLabel, gbc);


        diapasonStartSlider = new JSlider(JSlider.HORIZONTAL,-10,10,0);
        diapasonStartSlider.setPreferredSize(dim);
        diapasonStartSlider.setMajorTickSpacing(2);
        diapasonStartSlider.setMinorTickSpacing(1);
        diapasonStartSlider.setPaintTicks(true);
        diapasonStartSlider.setPaintLabels(true);
        diapasonStartSlider.setBackground(color);
        gbc.gridx = 0;
        gbc.gridy = 1;
        left.add(diapasonStartSlider, gbc);
        diapasonStartSlider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                if(slider){
                    if(diapasonStartSlider.getValue()> diapasonEndSlider.getValue()){
                        diapasonStartSlider.setValue(diapasonEndSlider.getValue());
                    }
                    slider = false;
                    diapSpinnerStart.setValue(diapasonStartSlider.getValue());
                }
                slider = true;
            }
        });

        diapasonEndSlider = new JSlider(JSlider.HORIZONTAL,-10,10,4);
        diapasonEndSlider.setPreferredSize(dim);
        diapasonEndSlider.setMajorTickSpacing(2);
        diapasonEndSlider.setMinorTickSpacing(1);
        diapasonEndSlider.setPaintTicks(true);
        diapasonEndSlider.setPaintLabels(true);
        diapasonEndSlider.setBackground(color);
        gbc.gridx = 0;
        gbc.gridy = 2;
        left.add(diapasonEndSlider, gbc);
        diapasonEndSlider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                if(slider) {
                    if (diapasonEndSlider.getValue() < diapasonStartSlider.getValue()) {
                        diapasonEndSlider.setValue(diapasonStartSlider.getValue());
                    }
                    slider = false;
                    diapSpinnerEnd.setValue(diapasonEndSlider.getValue());
                }
                slider = true;
            }
        });

        JLabel aParLabel = new JLabel("Parameter a: r=aφ");
        aParLabel.setFont(font);
        gbc.gridx = 0;
        gbc.gridy = 0;
        center.add(aParLabel, gbc);

        aParSlider = new JSlider(JSlider.HORIZONTAL,-20,20,1);
        aParSlider.setPreferredSize(dim);
        aParSlider.setMajorTickSpacing(5);
        aParSlider.setMinorTickSpacing(1);
        aParSlider.setPaintTicks(true);
        aParSlider.setPaintLabels(true);
        aParSlider.setBackground(color);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.insets = new Insets(0,100,0,100);
        center.add(aParSlider, gbc);
        aParSlider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                if(slider) {
                    slider = false;
                    aParSpinner.setValue(aParSlider.getValue());
                }
                slider = true;
            }
        });

        JLabel stepLabel = new JLabel("Step = π/?");
        stepLabel.setFont(font);
        gbc.gridx = 0;
        gbc.gridy = 0;
        right.add(stepLabel, gbc);

        stepSlider = new JSlider(JSlider.HORIZONTAL, 4, 136, 32);
        stepSlider.setPreferredSize(dim);
        stepSlider.setMajorTickSpacing(12);
        stepSlider.setMinorTickSpacing(3);
        stepSlider.setPaintTicks(true);
        stepSlider.setPaintLabels(true);
        stepSlider.setBackground(color);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.insets = new Insets(0,0,0,0);
        right.add(stepSlider, gbc);
        stepSlider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                if(slider) {
                    slider = false;
                    stepSpinner.setValue(stepSlider.getValue());
                }
                slider = true;
            }
        });

        gbc.gridx = 0;
        gbc.gridy = 0;
        settings.add(left,gbc);

        gbc.gridx = 1;
        settings.add(center,gbc);

        gbc.gridx = 2;
        settings.add(right,gbc);
    }

    /**Starts the program*/
    public static void main(String[] args) {
        Main main = new Main();
    }

}
