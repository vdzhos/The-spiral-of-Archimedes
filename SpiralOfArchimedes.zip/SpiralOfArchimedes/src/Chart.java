import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.block.BlockBorder;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.ValueMarker;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.util.ShapeUtils;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import java.awt.*;
import java.awt.geom.Ellipse2D;

public class Chart {

    /**The component, which displays the graph*/
    private JFreeChart chart;

    /**"a" parameter*/
    private int aPar = 1;
    /**Start of the diapason of φ ("s" parameter)*/
    private int diapasonStart = 0;
    /**End of the diapason of φ ("e" parameter)*/
    private int diapasonEnd = 4;
    /**The change of the angle to find the points of the graph (step parameter)*/
    private double step = Math.PI/32;

    /**Creates the Chart object, which holds the JFreeChart component, based on a generated dataset*/
    public Chart(){
        XYDataset dataset = generateDataset();
        chart = createChart(dataset);
    }

    /**Generates the dataset, based on 4 parameters (a,s,e,step)*/
    public XYDataset generateDataset() {
        XYSeries series = new XYSeries("Spiral of Archimedes",false);
        double r = 0;
        for (double i = diapasonStart*Math.PI; i <= diapasonEnd *Math.PI; i+=step) {
            r = aPar*i;
            series.add(r*Math.cos(i),r*Math.sin(i));
        }
        if(r > 0 && r < aPar*diapasonEnd *Math.PI){
            r = aPar* diapasonEnd *Math.PI;
            series.add(r*Math.cos(diapasonEnd *Math.PI),r*Math.sin(diapasonEnd *Math.PI));
        }else if(r<0 && r > aPar*diapasonEnd *Math.PI){
            r = aPar* diapasonEnd *Math.PI;
            series.add(r*Math.cos(diapasonEnd *Math.PI),r*Math.sin(diapasonEnd *Math.PI));
        }

        XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(series);

        return dataset;
    }

    /**@param dataset - the dataset, which the new JFreeChart component will use
     * Initialises the JFreeChart component, based on a dataset*/
    private JFreeChart createChart(XYDataset dataset) {

        JFreeChart chart = ChartFactory.createXYLineChart(null, "X Axis", "Y Axis", dataset,
                PlotOrientation.VERTICAL, true, true, false);

        XYPlot plot = chart.getXYPlot();

        XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
        renderer.setSeriesPaint(0, Color.RED);
        renderer.setSeriesStroke(0, new BasicStroke(1.5f));
        renderer.setSeriesShape(0, ShapeUtils.createTranslatedShape(new Ellipse2D.Double(0,0,5,5),-2.5,-2.5));

        plot.setRenderer(renderer);
        plot.setBackgroundPaint(Color.white);

        plot.setRangeGridlinesVisible(true);
        plot.setRangeGridlinePaint(Color.BLACK);

        plot.setDomainGridlinesVisible(true);
        plot.setDomainGridlinePaint(Color.BLACK);

        plot.addRangeMarker(new ValueMarker(0,Color.BLACK,new BasicStroke()));
        plot.addDomainMarker(new ValueMarker(0,Color.BLACK,new BasicStroke()));
        plot.setDomainPannable(true);
        plot.setRangePannable(true);

        chart.getLegend().setFrame(BlockBorder.NONE);

        return chart;
    }

    /**Returns the JFreeChart component*/
    public JFreeChart getChart() {
        return chart;
    }

    /**@param aPar - the new "a" parameter
     * Setter for "a" parameter*/
    public void setAPar(int aPar) {
        this.aPar = aPar;
    }

    /**@param diapasonStart - the new "s" parameter
     * Setter for "s" parameter (start of the diapason of φ)*/
    public void setDiapasonStart(int diapasonStart) {
        this.diapasonStart = diapasonStart;
    }

    /**@param diapasonEnd - the new "e" parameter
     * Setter for "e" parameter (end of the diapason of φ)*/
    public void setDiapasonEnd(int diapasonEnd) {
        this.diapasonEnd = diapasonEnd;
    }

    /**@param step - the new step parameter
     * Setter for step parameter (the change of the angle to find the points of the graph)*/
    public void setStep(int step) {
        this.step = Math.PI/step;
    }
}
